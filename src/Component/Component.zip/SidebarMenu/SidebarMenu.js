import React from 'react';
import './SidebarMenu.css';

const SidebarMenu = () => {
  return (
    <div className="sidebar-menu">

      <p>Tokenomics</p>
      <p>MoonSea</p>
      <p>Moonshot</p>

    </div>
  );
};

export default SidebarMenu;
